function resolvedPromise(msg) {
    let promise = new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve(msg)
        }, 500)
    })
    
    return promise;
}


function rejectedPromise(err) {
    let promise = new Promise((resolve, reject) => {
        setTimeout(() => {
            reject(err)
        }, 500)
    })
    
    return promise;
}

resolvedPromise("Resolved Promise success")
.then(data => {
    console.log(`{message: ${data}}`);
}).catch(err => {
    console.log(`{error: ${err}}`)
})

rejectedPromise("Rejected Promise error")
.then(data => {
    console.log(`{message: ${data}}`);
}).catch(err => {
    console.log(`{error: ${err}}`)
})