function lowerCaseWords(input_array) {
    let promise = new Promise((resolve, reject) => {
        if (Array.isArray(input_array)) {
            let filtered_words = input_array.filter(element => typeof element === "string");
        let lowercase_filtered_word = filtered_words.map(item => item.toLowerCase());

        if (lowercase_filtered_word.length === 0) {
            reject("Input array does not contain valid words.");
          } else {
            resolve(lowercase_filtered_word);
          }
          
        } else {
            reject("Input is not an Array");
        }
    });
    return promise
}

let test_array = ['PIZZA', 10, true, 25, false, 'Wings'];
let lowercasewords = lowerCaseWords(test_array)


lowercasewords.then(data => {
    console.log(data);
}).catch(error => {
    console.log(error);
})