const fs = require('fs');
const path = require('path');

let folder = path.join(__dirname, 'Logs')

try {
    if (!fs.existsSync(folder)) {
        fs.mkdir(folder, (err) => {
            if (err) {throw err}
        })
        
        for (let i = 0; i <= 9; i++) {
            let log_file_name = `log${i}.txt`;
            let log_file_path = path.join(folder, log_file_name)
            let log_file_content = `Log file${i}`;

            fs.appendFile(log_file_path, log_file_content, (err) => {
                if (err) throw err;
                console.log(log_file_name);
              }); 
            
        }

    } else {
        console.log("Folder exists!");
    }
} catch (error) {
    console.log(error)
}