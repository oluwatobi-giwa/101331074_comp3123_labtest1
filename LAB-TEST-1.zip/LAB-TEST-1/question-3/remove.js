const fs = require('fs');
const path = require('path');

let folder = './Logs'

try {
    if (fs.existsSync(folder) && fs.statSync(folder).isDirectory()) {
        fs.readdir(folder, (err, files) => {
            if (files.length) {
                files.forEach(file => {
                    console.log(file);
                })
    
                files.forEach(del_file => {
                    fs.unlink(folder+'/'+del_file, (err) => {
                        if(err) {throw err}
                        console.log('delete files...'+del_file);
                    })
                })
            } else {
                fs.rmdir(folder, (err) =>{
                    if (err) {throw err}
                })
            }
            
        })

    }
} catch (error) {
    console.log(error)
}